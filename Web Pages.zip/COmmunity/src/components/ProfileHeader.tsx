import React from 'react';
import { Camera, Edit2 } from 'lucide-react';
import type { UserProfile } from '../types/user';

interface ProfileHeaderProps {
  profile: UserProfile;
  onEditProfile: () => void;
  onAvatarChange: (file: File) => void;
}

export function ProfileHeader({ profile, onEditProfile, onAvatarChange }: ProfileHeaderProps) {
  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      onAvatarChange(e.target.files[0]);
    }
  };

  return (
    <div className="relative mb-8">
      <div 
        className="h-64 bg-cover bg-center"
        style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1604871000636-074fa5117945?w=1600)',
          backgroundBlendMode: 'overlay',
          backgroundColor: 'rgba(91, 33, 182, 0.7)'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-purple-900/50"></div>
      </div>
      <div className="container mx-auto px-4">
        <div className="relative -mt-32 flex items-end space-x-6">
          <div className="relative group">
            <img
              src={profile.avatar}
              alt={profile.name}
              className="w-40 h-40 rounded-full border-4 border-white shadow-lg object-cover"
            />
            <label className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity">
              <Camera className="w-8 h-8 text-white" />
              <input type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
            </label>
          </div>
          <div className="mb-4">
            <h1 className="text-4xl font-bold text-white mb-2">{profile.name}</h1>
            <p className="text-purple-50 mb-4 max-w-2xl">{profile.bio}</p>
            <button
              onClick={onEditProfile}
              className="inline-flex items-center px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-purple-50 transition-colors"
            >
              <Edit2 className="w-4 h-4 mr-2" />
              Edit Profile
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}