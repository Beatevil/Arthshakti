import React from 'react';
import type { Badge } from '../types/user';

interface BadgesSectionProps {
  badges: Badge[];
}

export function BadgesSection({ badges }: BadgesSectionProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-xl font-semibold mb-4">Achievements & Badges</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {badges.map((badge) => (
          <div
            key={badge.id}
            className="group relative flex flex-col items-center p-4 rounded-lg bg-gray-50 hover:bg-purple-50 transition-colors"
          >
            <div className="w-16 h-16 flex items-center justify-center bg-purple-100 rounded-full mb-2">
              <img src={badge.icon} alt={badge.name} className="w-8 h-8" />
            </div>
            <h3 className="text-sm font-medium text-center">{badge.name}</h3>
            <div className="absolute invisible group-hover:visible opacity-0 group-hover:opacity-100 transition-opacity bg-gray-900 text-white text-xs rounded py-1 px-2 -top-2 left-1/2 transform -translate-x-1/2 w-48 text-center">
              {badge.description}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}