import React from 'react';
import { Trophy, Calendar, Briefcase } from 'lucide-react';
import type { UserProfile } from '../types/user';

interface ProgressSectionProps {
  progress: UserProfile['progress'];
}

export function ProgressSection({ progress }: ProgressSectionProps) {
  const progressPercentage = (progress.coursesCompleted / progress.totalCourses) * 100;

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-xl font-semibold mb-4">My Progress</h2>
      
      <div className="mb-6">
        <div className="flex justify-between mb-2">
          <span className="text-sm text-gray-600">Course Completion</span>
          <span className="text-sm font-medium">{progressPercentage.toFixed(0)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div
            className="bg-purple-600 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-100 rounded-full mb-2">
            <Trophy className="w-6 h-6 text-purple-600" />
          </div>
          <div className="text-2xl font-bold">{progress.coursesCompleted}</div>
          <div className="text-sm text-gray-600">Courses Completed</div>
        </div>
        
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-100 rounded-full mb-2">
            <Calendar className="w-6 h-6 text-purple-600" />
          </div>
          <div className="text-2xl font-bold">{progress.eventsAttended}</div>
          <div className="text-sm text-gray-600">Events Attended</div>
        </div>

        <div className="text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-100 rounded-full mb-2">
            <Briefcase className="w-6 h-6 text-purple-600" />
          </div>
          <div className="text-2xl font-bold">{progress.opportunitiesApplied}</div>
          <div className="text-sm text-gray-600">Opportunities Applied</div>
        </div>
      </div>
    </div>
  );
}