import React, { useState } from 'react';
import { ProfileHeader } from './components/ProfileHeader';
import { ProgressSection } from './components/ProgressSection';
import { BadgesSection } from './components/BadgesSection';
import { ActivityFeed } from './components/ActivityFeed';
import type { UserProfile } from './types/user';

const mockProfile: UserProfile = {
  id: '1',
  name: 'Rani Devi',
  avatar: 'https://www.visualsstock.com/images/Low/5/AK57279.jpg',
  bio: 'Passionate about empowering rural women through digital literacy and entrepreneurship.',
  skills: [
    { id: '1', name: 'Digital Marketing', level: 4 },
    { id: '2', name: 'Handicrafts', level: 5 },
    { id: '3', name: 'Leadership', level: 4 }
  ],
  badges: [
    {
      id: '1',
      name: 'Digital Champion',
      description: 'Completed all digital literacy modules with excellence',
      icon: 'https://img.icons8.com/color/96/000000/medal.png',
      earnedDate: '2024-02-15'
    },
    {
      id: '2',
      name: 'Community Leader',
      description: 'Led 5 successful community initiatives',
      icon: 'https://img.icons8.com/color/96/000000/conference.png',
      earnedDate: '2024-01-20'
    }
  ],
  activities: [
    {
      id: '1',
      type: 'course',
      title: 'Completed Digital Marketing Basics',
      description: 'Finished the course with 95% score',
      date: '2 days ago'
    },
    {
      id: '2',
      type: 'event',
      title: 'Attended Women Entrepreneurs Meet',
      description: 'Networked with 20+ fellow entrepreneurs',
      date: '1 week ago'
    }
  ],
  progress: {
    coursesCompleted: 8,
    totalCourses: 12,
    eventsAttended: 15,
    opportunitiesApplied: 7
  }
};

function App() {
  const [profile, setProfile] = useState<UserProfile>(mockProfile);

  const handleEditProfile = () => {
    // Implement edit profile modal
    console.log('Edit profile clicked');
  };

  const handleAvatarChange = (file: File) => {
    // Implement avatar upload logic
    console.log('Avatar change:', file);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <ProfileHeader
        profile={profile}
        onEditProfile={handleEditProfile}
        onAvatarChange={handleAvatarChange}
      />
      <div className="container mx-auto px-4 pt-20">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <ProgressSection progress={profile.progress} />
            <BadgesSection badges={profile.badges} />
          </div>
          <div className="lg:col-span-1">
            <ActivityFeed activities={profile.activities} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;