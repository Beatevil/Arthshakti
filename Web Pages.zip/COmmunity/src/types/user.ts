export interface Skill {
  id: string;
  name: string;
  level: number; // 1-5
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earnedDate: string;
}

export interface Activity {
  id: string;
  type: 'post' | 'event' | 'course' | 'opportunity';
  title: string;
  description: string;
  date: string;
}

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  skills: Skill[];
  badges: Badge[];
  activities: Activity[];
  progress: {
    coursesCompleted: number;
    totalCourses: number;
    eventsAttended: number;
    opportunitiesApplied: number;
  };
}