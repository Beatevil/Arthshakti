export interface Opportunity {
  id: string;
  title: string;
  description: string;
  category: string;
  location: string;
  type: string;
  imageUrl: string;
  company: string;
  postedDate: string;
  investment: number;
  monthlyIncome: string;
}