import React from 'react';
import { Opportunities } from './pages/Opportunities';

function App() {
  return <Opportunities />;
}

export default App;