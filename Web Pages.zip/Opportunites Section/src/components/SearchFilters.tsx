import React from 'react';
import { Search } from 'lucide-react';

interface SearchFiltersProps {
  search: string;
  setSearch: (value: string) => void;
  category: string;
  setCategory: (value: string) => void;
  location: string;
  setLocation: (value: string) => void;
  type: string;
  setType: (value: string) => void;
}

export function SearchFilters({
  search,
  setSearch,
  category,
  setCategory,
  location,
  setLocation,
  type,
  setType,
}: SearchFiltersProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-8 border border-purple-100">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search opportunities..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
        </div>
        <div className="flex flex-col md:flex-row gap-4 md:w-2/3">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            <option value="">All Categories</option>
            <option value="livestock">Livestock</option>
            <option value="farming">Farming</option>
            <option value="crafts">Crafts</option>
            <option value="textiles">Textiles</option>
          </select>
          <select
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            <option value="">All Locations</option>
            <option value="rural">Rural</option>
            <option value="semi-rural">Semi-Rural</option>
          </select>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            <option value="">All Types</option>
            <option value="business">Business</option>
            <option value="cooperative">Cooperative</option>
          </select>
        </div>
      </div>
    </div>
  );
}