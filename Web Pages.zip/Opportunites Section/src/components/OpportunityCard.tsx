import React from 'react';
import { Building2, MapPin, Tag, Calendar, IndianRupee, PiggyBank } from 'lucide-react';
import type { Opportunity } from '../types/opportunity';

interface OpportunityCardProps {
  opportunity: Opportunity;
}

function formatIndianCurrency(amount: number): string {
  const formatter = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  });
  return formatter.format(amount);
}

export function OpportunityCard({ opportunity }: OpportunityCardProps) {
  return (
    <div className="group bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border border-purple-100">
      <div className="relative h-48 overflow-hidden">
        <img
          src={opportunity.imageUrl}
          alt={opportunity.title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full text-sm font-medium text-purple-700 shadow-sm">
          {opportunity.category}
        </div>
      </div>
      <div className="p-6">
        <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
          <Building2 size={16} />
          <span>{opportunity.company}</span>
        </div>
        <h3 className="text-xl font-semibold mb-2 text-gray-900">{opportunity.title}</h3>
        <p className="text-gray-600 mb-4 line-clamp-2">{opportunity.description}</p>
        <div className="flex flex-wrap gap-3 mb-4">
          <div className="flex items-center gap-1 text-sm text-gray-600">
            <MapPin size={16} />
            <span>{opportunity.location}</span>
          </div>
          <div className="flex items-center gap-1 text-sm text-gray-600">
            <Tag size={16} />
            <span>{opportunity.type}</span>
          </div>
          <div className="flex items-center gap-1 text-sm text-gray-600">
            <Calendar size={16} />
            <span>{new Date(opportunity.postedDate).toLocaleDateString()}</span>
          </div>
        </div>
        <div className="flex flex-col gap-2 mb-4 p-3 bg-purple-50 rounded-md">
          <div className="flex items-center gap-2 text-sm text-purple-800">
            <PiggyBank size={16} />
            <span>Initial Investment: {formatIndianCurrency(opportunity.investment)}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-purple-800">
            <IndianRupee size={16} />
            <span>Monthly Income: ₹{opportunity.monthlyIncome}</span>
          </div>
        </div>
        <button className="w-full bg-purple-600 text-white py-2 px-4 rounded-md hover:bg-purple-700 transition-colors duration-200">
          Learn More
        </button>
      </div>
    </div>
  );
}