import React, { useState, useEffect } from 'react';
import { OpportunityCard } from '../components/OpportunityCard';
import { SearchFilters } from '../components/SearchFilters';
import { Loader } from 'lucide-react';
import type { Opportunity } from '../types/opportunity';

const MOCK_OPPORTUNITIES: Opportunity[] = [
  {
    id: '1',
    title: 'Dairy Farming Enterprise',
    description: 'Start a dairy farm with 10 cows. Initial investment covers cattle, shed construction, and equipment. Expected monthly income: ₹1,50,000-2,75,000.',
    category: 'livestock',
    location: 'rural',
    type: 'business',
    company: 'Rural Enterprise Initiative',
    imageUrl: 'https://images.unsplash.com/photo-1615811361523-6bd03d7748e7?auto=format&fit=crop&q=80',
    postedDate: '2024-03-15',
    investment: 2000000,
    monthlyIncome: '1,50,000-2,75,000'
  },
  {
    id: '2',
    title: 'Organic Vegetable Farm',
    description: 'Start an organic vegetable farm on 2 acres. Investment includes land preparation, seeds, and irrigation. Expected monthly income: ₹1,25,000-2,00,000.',
    category: 'farming',
    location: 'rural',
    type: 'business',
    company: 'Organic Farming Network',
    imageUrl: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&q=80',
    postedDate: '2024-03-14',
    investment: 1200000,
    monthlyIncome: '1,25,000-2,00,000'
  },
  {
    id: '3',
    title: 'Traditional Handicraft Workshop',
    description: 'Set up a handicraft production unit. Initial costs cover workspace, materials, and basic tools. Expected monthly income: ₹60,000-1,20,000.',
    category: 'crafts',
    location: 'rural',
    type: 'business',
    company: 'Artisan Collective',
    imageUrl: 'https://images.unsplash.com/photo-1606722590583-6951b5ea92ad?auto=format&fit=crop&q=80',
    postedDate: '2024-03-13',
    investment: 400000,
    monthlyIncome: '60,000-1,20,000'
  },
  {
    id: '4',
    title: 'Pottery Studio Setup',
    description: 'Establish a pottery studio with kiln and workspace. Investment includes equipment and initial materials. Expected monthly income: ₹80,000-1,50,000.',
    category: 'crafts',
    location: 'rural',
    type: 'business',
    company: 'Rural Arts Initiative',
    imageUrl: 'https://images.unsplash.com/photo-1609709295948-17d77cb2a69b?auto=format&fit=crop&q=80',
    postedDate: '2024-03-12',
    investment: 600000,
    monthlyIncome: '80,000-1,50,000'
  },
  {
    id: '5',
    title: 'Tailoring Business',
    description: 'Start a tailoring business with 3 machines. Covers equipment, workspace setup, and materials. Expected monthly income: ₹45,000-90,000.',
    category: 'textiles',
    location: 'rural',
    type: 'business',
    company: 'Rural Textile Network',
    imageUrl: 'https://images.unsplash.com/photo-1528578950694-9f79b95ac2c0?auto=format&fit=crop&q=80',
    postedDate: '2024-03-11',
    investment: 250000,
    monthlyIncome: '45,000-90,000'
  },
  {
    id: '6',
    title: 'Beekeeping Enterprise',
    description: 'Start a beekeeping business with 20 hives. Investment includes hives, equipment, and initial colony setup. Expected monthly income: ₹60,000-1,20,000.',
    category: 'livestock',
    location: 'rural',
    type: 'business',
    company: 'Rural Beekeepers Association',
    imageUrl: 'https://images.unsplash.com/photo-1587556930283-4b89973685f0?auto=format&fit=crop&q=80',
    postedDate: '2024-03-10',
    investment: 450000,
    monthlyIncome: '60,000-1,20,000'
  }
];

export function Opportunities() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [location, setLocation] = useState('');
  const [type, setType] = useState('');
  const [loading, setLoading] = useState(true);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);

  useEffect(() => {
    const loadOpportunities = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1000));
      setOpportunities(MOCK_OPPORTUNITIES);
      setLoading(false);
    };

    loadOpportunities();
  }, []);

  const filteredOpportunities = opportunities.filter(opp => {
    const matchesSearch = opp.title.toLowerCase().includes(search.toLowerCase()) ||
      opp.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = !category || opp.category === category;
    const matchesLocation = !location || opp.location === location;
    const matchesType = !type || opp.type === type;

    return matchesSearch && matchesCategory && matchesLocation && matchesType;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-purple-900 mb-4">Women's Rural Empowerment Opportunities</h1>
          <p className="text-xl text-purple-700">Discover sustainable business opportunities for women in rural areas</p>
        </div>

        <SearchFilters
          search={search}
          setSearch={setSearch}
          category={category}
          setCategory={setCategory}
          location={location}
          setLocation={setLocation}
          type={type}
          setType={setType}
        />

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <Loader className="animate-spin text-purple-600" size={48} />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredOpportunities.map(opportunity => (
              <OpportunityCard key={opportunity.id} opportunity={opportunity} />
            ))}
          </div>
        )}

        {!loading && filteredOpportunities.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">No opportunities found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
}