import React, { useEffect } from 'react';
import { Users, Tractor, Milk, GraduationCap, ChevronRight, User, Calendar, MessageSquare, Heart } from 'lucide-react';

function App() {
  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
          entry.target.classList.remove('opacity-0');
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);

    document.querySelectorAll('.animate-on-scroll').forEach((el) => {
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const navItems = [
    { name: 'Opportunities', icon: Heart },
    { name: 'Profile', icon: User },
    { name: 'Community', icon: Users },
    { name: 'Events', icon: Calendar },
    { name: 'Feedback', icon: MessageSquare }
  ];

  const categories = [
    {
      icon: Tractor,
      title: 'Agriculture',
      description: 'Empowering farmers with modern techniques and sustainable practices',
      image: 'https://images.unsplash.com/photo-1615811361523-6bd03d7748e7?auto=format&fit=crop&q=80&w=600'
    },
    {
      icon: Milk,
      title: 'Dairy',
      description: 'Supporting dairy farmers with innovative solutions and market access',
      image: 'https://images.unsplash.com/photo-1631009144506-a2a85fe4d494?auto=format&fit=crop&q=80&w=600'
    },
    {
      icon: GraduationCap,
      title: 'Teaching',
      description: 'Educating communities for a better tomorrow through skill development',
      image: 'https://images.unsplash.com/photo-1583468982228-19f19164aee2?auto=format&fit=crop&q=80&w=600'
    }
  ];

  const testimonials = [
    {
      quote: "ARTHSHAKTI has transformed my farming practices. My yield has increased by 40% this year!",
      author: "Lakshmi Devi",
      role: "Farmer",
      image: "https://images.unsplash.com/photo-1621184455862-c163dfb30e0f?auto=format&fit=crop&q=80&w=200&h=200"
    },
    {
      quote: "The dairy program helped me establish a successful business that supports my entire family.",
      author: "Priya Singh",
      role: "Dairy Farmer",
      image: "https://images.unsplash.com/photo-1597176116047-876a32798fcc?auto=format&fit=crop&q=80&w=200&h=200"
    }
  ];

  return (
    <div className="min-h-screen bg-[#FAF5FF]">
      {/* Navigation Header */}
      <nav className="fixed w-full z-50 bg-white/80 backdrop-blur-md shadow-sm">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <Users className="w-8 h-8 text-[#9F7AEA]" />
              <span className="text-xl font-bold text-[#553C9A]">ARTHSHAKTI</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              {navItems.map((item, index) => (
                <a
                  key={index}
                  href={`#${item.name.toLowerCase()}`}
                  className="flex items-center space-x-1 text-[#553C9A] hover:text-[#9F7AEA] transition-colors"
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center bg-gradient-to-br from-[#FAF5FF] to-[#E9D8FD] pt-16">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1603188737944-8b73b69420dd?auto=format&fit=crop&q=80"
            alt="Rural women working"
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="relative z-10 text-center px-4 animate-on-scroll opacity-0">
          <h1 className="text-5xl md:text-7xl font-bold text-[#44337A] mb-6">
            Empowering Rural India
          </h1>
          <p className="text-xl md:text-2xl text-[#553C9A] mb-8 max-w-2xl mx-auto">
            Building stronger communities through sustainable development and education
          </p>
          <button className="bg-[#9F7AEA] text-white px-8 py-4 rounded-full text-lg font-semibold 
            hover:bg-[#805AD5] transform hover:scale-105 transition-all duration-300 flex items-center mx-auto">
            Join Now
            <ChevronRight className="ml-2" />
          </button>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 px-4 bg-[#FAF5FF] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img 
            src="https://images.unsplash.com/photo-1597385573259-d2d9f0b7135d?auto=format&fit=crop&q=80"
            alt="Women in agriculture"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="max-w-4xl mx-auto text-center animate-on-scroll opacity-0 relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-[#44337A] mb-6">Our Mission</h2>
          <p className="text-lg text-[#553C9A] leading-relaxed">
            ARTHSHAKTI is dedicated to uplifting rural communities through sustainable development, 
            innovative agricultural practices, and comprehensive education programs. We believe in 
            creating lasting impact by empowering individuals with knowledge and resources.
          </p>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 px-4 bg-[#E9D8FD]">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#44337A] mb-12">What We Do</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {categories.map((category, index) => (
              <div 
                key={index}
                className="animate-on-scroll opacity-0 bg-white rounded-xl shadow-lg hover:shadow-xl 
                  transform hover:scale-105 transition-all duration-300 overflow-hidden"
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={category.image}
                    alt={category.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-8">
                  <div className="flex items-center mb-4">
                    <category.icon className="w-8 h-8 text-[#9F7AEA] mr-3" />
                    <h3 className="text-xl font-semibold text-[#44337A]">{category.title}</h3>
                  </div>
                  <p className="text-[#553C9A]">{category.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-[#FAF5FF] relative">
        <div className="absolute inset-0 opacity-5">
          <img 
            src="https://images.unsplash.com/photo-1602052793312-b99c2a9ee797?auto=format&fit=crop&q=80"
            alt="Women farmers"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="max-w-6xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#44337A] mb-12">Success Stories</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index}
                className="animate-on-scroll opacity-0 bg-white p-8 rounded-xl shadow-lg"
              >
                <div className="flex items-center mb-6">
                  <img 
                    src={testimonial.image}
                    alt={testimonial.author}
                    className="w-16 h-16 rounded-full object-cover mr-4 border-4 border-[#E9D8FD]"
                  />
                  <div>
                    <h4 className="font-semibold text-[#44337A]">{testimonial.author}</h4>
                    <p className="text-[#553C9A]">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-[#553C9A] italic">"{testimonial.quote}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#44337A] text-white py-8 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center mb-4">
            <Users className="w-8 h-8 text-[#E9D8FD]" />
          </div>
          <p className="text-[#E9D8FD]">© 2024 ARTHSHAKTI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;